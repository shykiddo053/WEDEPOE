/* Full JS for Part 3 features: validation, storage, display, lightbox, search, modal, dynamic year */
document.addEventListener('DOMContentLoaded', () => {
  // dynamic year
  document.querySelectorAll('[id^="year"]').forEach(el => el.textContent = new Date().getFullYear());

  // smooth scroll
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', function(e){
      const href = this.getAttribute('href');
      if(!href.startsWith('#')) return;
      e.preventDefault();
      const id = href.slice(1);
      const target = document.getElementById(id);
      if(target) target.scrollIntoView({behavior: 'smooth'});
    });
  });

  // product search
  const search = document.getElementById('productSearch');
  if(search){
    search.addEventListener('input', () => {
      const q = search.value.trim().toLowerCase();
      document.querySelectorAll('.product-item').forEach(item => {
        item.style.display = item.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  }

  // Enquiries storage (client-side)
  const ENQ_KEY = 'stb_enquiries_v1';
  function loadEnquiries(){
    try{
      const raw = localStorage.getItem(ENQ_KEY);
      return raw ? JSON.parse(raw) : [];
    }catch(e){ return []; }
  }
  function saveEnquiries(arr){
    localStorage.setItem(ENQ_KEY, JSON.stringify(arr));
  }
  function renderEnquiries(){
    const area = document.getElementById('storedArea');
    if(!area) return;
    const list = loadEnquiries();
    if(list.length === 0){
      area.innerHTML = '<p>No enquiries stored yet.</p>';
      return;
    }
    // build table
    let html = '<table><thead><tr><th>Date</th><th>Name</th><th>Type</th><th>Contact</th><th>Message</th></tr></thead><tbody>';
    list.forEach(e => {
      html += `<tr><td>${e.date}</td><td>${escapeHtml(e.fullname)}</td><td>${escapeHtml(e.type)}</td><td>${escapeHtml(e.email)} / ${escapeHtml(e.phone)}</td><td>${escapeHtml(e.details)}</td></tr>`;
    });
    html += '</tbody></table>';
    area.innerHTML = html;
  }

  function escapeHtml(s){ return String(s).replace(/[&<>"']/g, function(m){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]; }); }

  // Enquiry form handling
  const enquiryForm = document.getElementById('enquiryForm');
  if(enquiryForm){
    enquiryForm.addEventListener('submit', (ev) => {
      ev.preventDefault();
      const fullname = document.getElementById('fullname');
      const email = document.getElementById('email');
      const phone = document.getElementById('phone');
      const type = document.getElementById('type');
      const details = document.getElementById('details');
      const resp = document.getElementById('formResponse');

      // clear previous errors
      [fullname,email,phone,type,details].forEach(f => f.classList.remove('error'));
      resp.textContent = '';

      const errors = [];
      if(!fullname.value.trim()) errors.push('Name is required.');
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) errors.push('Valid email required.');
      if(!phone.value.trim() || phone.value.trim().length < 7) errors.push('Valid phone required.');
      if(!type.value) errors.push('Please select an enquiry type.');
      if(!details.value.trim() || details.value.trim().length < 10) errors.push('Please add at least 10 characters in message.');

      if(errors.length){
        resp.textContent = errors.join(' ');
        resp.classList.add('error-msg');
        // mark fields
        if(!fullname.value.trim()) fullname.classList.add('error');
        if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) email.classList.add('error');
        if(!phone.value.trim() || phone.value.trim().length < 7) phone.classList.add('error');
        if(!type.value) type.classList.add('error');
        if(!details.value.trim() || details.value.trim().length < 10) details.classList.add('error');
        return;
      }

      resp.textContent = 'Processing...';
      // simulate async
      setTimeout(() => {
        const now = new Date();
        const item = {
          date: now.toLocaleString(),
          fullname: fullname.value.trim(),
          email: email.value.trim(),
          phone: phone.value.trim(),
          type: type.value,
          details: details.value.trim()
        };
        const list = loadEnquiries();
        list.unshift(item);
        saveEnquiries(list);
        renderEnquiries();
        // templated estimate
        const msg = details.value.toLowerCase();
        let estimate = 'A staff member will contact you with pricing and availability.';
        if(msg.includes('wedding') || msg.includes('50') || msg.includes('500')) estimate = 'Estimated starting cost for a wedding-size cake: R2500 (final quote on consultation).';
        else if(msg.includes('birthday') || msg.includes('cake')) estimate = 'Estimated starting cost for a custom birthday cake: R450–R1200.';
        resp.textContent = `Thanks ${fullname.value.split(' ')[0]}! ${estimate}`;
        resp.style.color = 'green';
        enquiryForm.reset();
      }, 800);
    });

    // clear stored enquiries
    const clearBtn = document.getElementById('clearEnquiries');
    if(clearBtn){
      clearBtn.addEventListener('click', () => {
        if(confirm('Clear all stored enquiries (client-side)?')) {
          localStorage.removeItem(ENQ_KEY);
          renderEnquiries();
        }
      });
    }
  }

  // initial render
  renderEnquiries();

  // Contact form handling (mailto assembly)
  const contactForm = document.getElementById('contactForm');
  if(contactForm){
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const cname = document.getElementById('cname').value.trim();
      const cemail = document.getElementById('cemail').value.trim();
      const cmessage = document.getElementById('cmessage').value.trim();
      const cresp = document.getElementById('contactResponse');
      cresp.textContent = '';

      if(!cname || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cemail) || cmessage.length < 5){
        cresp.textContent = 'Please provide a valid name, email and message.';
        cresp.classList.add('error-msg');
        return;
      }

      const subject = encodeURIComponent(`Website message from ${cname}`);
      const body = encodeURIComponent(`Name: ${cname}\nEmail: ${cemail}\n\nMessage:\n${cmessage}`);
      const mailto = `mailto:info@sweettreatsbakery.co.za?subject=${subject}&body=${body}`;
      cresp.innerHTML = `Message ready. <a href="${mailto}" target="_blank" rel="noopener">Open your email client to send</a>.`;
      contactForm.reset();
    });
  }

  // lightbox
  document.querySelectorAll('.card img').forEach(img => {
    img.addEventListener('click', () => {
      const overlay = document.createElement('div');
      overlay.style.position='fixed'; overlay.style.inset=0; overlay.style.background='rgba(0,0,0,0.85)'; overlay.style.display='flex'; overlay.style.alignItems='center'; overlay.style.justifyContent='center'; overlay.style.zIndex=9999;
      overlay.addEventListener('click', () => overlay.remove());
      const big = document.createElement('img'); big.src = img.src; big.alt = img.alt || ''; big.style.maxWidth='90%'; big.style.maxHeight='90%'; big.style.borderRadius='6px';
      overlay.appendChild(big); document.body.appendChild(overlay);
    });
  });

});
